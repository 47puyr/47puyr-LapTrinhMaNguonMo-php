
<?php $__env->startSection('page_title', isset($rec) ? 'Cập nhật lớp: '.$rec->name : 'Thêm lớp'); ?>
<?php $__env->startSection('slot'); ?>
<form id="form" class="text-start" method="POST"
    action="<?php echo e(isset($rec) ? route('classes.update', ['id' => $rec->id]) : route('classes.create')); ?>">
    <?php echo e(csrf_field()); ?>

    <label class="form-label mt-3">Tên lớp *</label>
    <div class="input-group input-group-outline">
        <input type="text" name="name" class="form-control" required value="<?php echo e($rec->name ?? old('name') ?? ''); ?>">
    </div>

    <input type="submit" class="btn bg-gradient-primary my-4 mb-2" value="<?php echo e(isset($rec) ? 'Cập nhật' : 'Thêm'); ?>">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php bt\DoAn\da\da\resources\views/classes/form.blade.php ENDPATH**/ ?>