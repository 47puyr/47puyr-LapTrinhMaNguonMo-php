
<?php $__env->startSection('page_title', 'Giáo viên'); ?>
<?php $__env->startSection('slot'); ?>
<div class="card">
    <div class="card-body px-0 pb-2">
        <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
                <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Họ và tên</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Ngày sinh</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mã số giáo viên</th>
                        <th class="text-secondary opacity-7"></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-xs">Nguyễn Văn A</td>
                        <td class="text-xs">01/01/2003</td>
                        <td class="text-xs">ABC0123</td>
                        <td class="align-middle">
                            <a class="text-secondary font-weight-bold text-xs">Sửa</a> | 
                            <a class="text-secondary font-weight-bold text-xs">Xóa</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\Github\da\resources\views/teachers.blade.php ENDPATH**/ ?>