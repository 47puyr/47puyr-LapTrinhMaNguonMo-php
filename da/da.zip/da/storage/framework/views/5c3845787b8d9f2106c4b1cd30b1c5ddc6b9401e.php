
<?php $__env->startSection('page_title', 'Môn học'); ?>
<?php $__env->startSection('slot'); ?>
<button class="btn btn-primary">Thêm môn học <i class="material-icons">add</i></button>
<div class="card">
    <div class="card-body px-0 pb-2">
        <div class="table-responsive p-0">
            <table class="table align-items-center mb-0">
                <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Tên môn</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Mã môn</th>
                        <th class="text-secondary opacity-7"></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-xs">Toán cao cấp A1</td>
                        <td class="text-xs">A1</td>
                        <td class="align-middle">
                            <a class="text-secondary font-weight-bold text-xs">Sửa</a> | 
                            <a class="text-secondary font-weight-bold text-xs">Xóa</a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\Github\da\resources\views/subjects.blade.php ENDPATH**/ ?>