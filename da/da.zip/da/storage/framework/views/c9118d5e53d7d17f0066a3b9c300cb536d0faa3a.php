
<?php $__env->startSection('page_title', isset($rec) ? 'Cập nhật giáo viên: '.$rec->name : 'Thêm giáo viên'); ?>
<?php $__env->startSection('slot'); ?>
<form id="form" class="text-start" method="POST"
    action="<?php echo e(isset($rec) ? route('teachers.update', ['id' => $rec->id]) : route('teachers.create')); ?>">
    <?php echo e(csrf_field()); ?>

    <label class="form-label mt-3">Họ và tên *</label>
    <div class="input-group input-group-outline">
        <input type="text" name="name" class="form-control" required value="<?php echo e($rec->name ?? old('name') ?? ''); ?>">
    </div>

    <label class="form-label mt-3">Tên tài khoản *</label>
    <div class="input-group input-group-outline">
        <input type="text" name="username" class="form-control" required value="<?php echo e($rec->username ?? old('username') ?? ''); ?>">
    </div>

    <label class="form-label mt-3">Email *</label>
    <div class="input-group input-group-outline">
        <input type="email" name="email" class="form-control" required value="<?php echo e($rec->email ?? old('email') ?? ''); ?>">
    </div>

    <label class="form-label mt-3">Mật khẩu <?php echo e(isset($rec) ? '' : '*'); ?></label>
    <div class="input-group input-group-outline">
        <input type="password" name="password" class="form-control input-outline" <?php echo e(isset($rec) ? '' : 'required'); ?>>
    </div>
    <input type="submit" class="btn bg-gradient-primary my-4 mb-2" value="<?php echo e(isset($rec) ? 'Cập nhật' : 'Thêm'); ?>">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\da\resources\views/teachers/form.blade.php ENDPATH**/ ?>